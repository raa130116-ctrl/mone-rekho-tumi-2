বাংলা ক্যালকুলেটর Android প্রজেক্ট
অ্যাপের নাম: মনে রেখো তুমি

এই ফোল্ডারটি Android Studio-তে খুলে APK তৈরি করা যাবে।

যা লাগবে:
- Android Studio (কম্পিউটার/ল্যাপটপে)
- Android SDK Platform 35
- JDK 17

APK তৈরির ধাপ:
1. Android Studio ইনস্টল করে চালু করুন।
2. Open নির্বাচন করে এই প্রজেক্টের মূল ফোল্ডার `mone_rekho_tumi_android` নির্বাচন করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. সফল হলে app/build/outputs/apk/debug/app-debug.apk ফাইল পাওয়া যাবে।
6. APK ফোনে পাঠিয়ে ইনস্টল করুন। ফোনে “Install unknown apps” অনুমতি চাইলে কেবল নিজের তৈরি APK-র জন্য অনুমতি দিন।

গুরুত্বপূর্ণ:
- এটি Android Studio প্রজেক্ট; এটি নিজে APK ফাইল নয়।
- এই প্রজেক্টে ক্যালকুলেটর অফলাইনে চলে এবং ইন্টারনেট পারমিশন চায় না।
- অ্যাপের নাম strings.xml-এ পরিবর্তন করা যাবে।
