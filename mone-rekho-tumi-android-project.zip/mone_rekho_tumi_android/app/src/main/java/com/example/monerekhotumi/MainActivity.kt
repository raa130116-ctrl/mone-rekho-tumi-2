\
package com.example.monerekhotumi

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.math.BigDecimal
import java.math.MathContext
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 24, 39)
    private val panel = Color.rgb(28, 41, 59)
    private val green = Color.rgb(22, 123, 104)
    private val mint = Color.rgb(112, 226, 181)
    private val white = Color.rgb(244, 247, 251)
    private val muted = Color.rgb(168, 185, 204)

    private lateinit var first: EditText
    private lateinit var second: EditText
    private lateinit var answer: TextView
    private lateinit var equation: TextView
    private lateinit var error: TextView
    private var operation = "+"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val scroll = android.widget.ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "মনে রেখো তুমি"
            textSize = 25f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "বাংলা ক্যালকুলেটর • ইন্টারনেট ছাড়াই"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(22))
        }
        root.addView(subtitle, matchWrap())

        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        root.addView(fields, matchWrap())

        fields.addView(label("প্রথম সংখ্যা"))
        first = numberInput("প্রথম সংখ্যা লিখুন", "25")
        fields.addView(first, matchWrap())
        fields.addView(label("দ্বিতীয় সংখ্যা").apply { setPadding(0, dp(14), 0, dp(6)) })
        second = numberInput("দ্বিতীয় সংখ্যা লিখুন", "5")
        fields.addView(second, matchWrap())

        root.addView(label("হিসাবের ধরন নির্বাচন করুন").apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setPadding(0, dp(22), 0, dp(12))
        })

        val ops = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf("+" to "যোগ", "-" to "বিয়োগ", "*" to "গুণ", "/" to "ভাগ").forEach { (symbol, name) ->
            val b = Button(this).apply {
                text = "$symbol\n$name"
                textSize = 15f
                isAllCaps = false
                setTextColor(white)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (operation == symbol) green else Color.rgb(38, 52, 72)))
                setOnClickListener {
                    operation = symbol
                    for (i in 0 until ops.childCount) {
                        val child = ops.getChildAt(i) as Button
                        val key = listOf("+", "-", "*", "/")[i]
                        child.setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (key == operation) green else Color.rgb(38, 52, 72)))
                    }
                    calculate()
                }
            }
            ops.addView(b, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                marginEnd = dp(5)
            })
        }
        root.addView(ops, matchWrap())

        val calculate = Button(this).apply {
            text = "＝ হিসাব করুন"
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
            setOnClickListener { calculate() }
        }
        root.addView(calculate, LinearLayout.LayoutParams(-1, dp(54)).apply {
            topMargin = dp(16)
        })

        val resultPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(24, 61, 58))
        }
        root.addView(resultPanel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(15) })
        resultPanel.addView(TextView(this).apply {
            text = "হিসাবের ফলাফল"
            textSize = 13f
            setTextColor(Color.rgb(158, 216, 199))
        })
        answer = TextView(this).apply {
            text = "—"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(mint)
            setPadding(0, dp(5), 0, dp(4))
        }
        resultPanel.addView(answer, matchWrap())
        equation = TextView(this).apply {
            text = "ফলাফল এখানে দেখা যাবে"
            textSize = 14f
            setTextColor(Color.rgb(193, 221, 213))
        }
        resultPanel.addView(equation, matchWrap())
        error = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(255, 180, 169))
        }
        resultPanel.addView(error, matchWrap())

        val clear = Button(this).apply {
            text = "↻ সব মুছে ফেলুন"
            textSize = 15f
            isAllCaps = false
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(38, 52, 72)))
            setOnClickListener {
                first.setText("")
                second.setText("")
                operation = "+"
                answer.text = "—"
                equation.text = "ফলাফল এখানে দেখা যাবে"
                error.text = ""
                first.requestFocus()
                for (i in 0 until ops.childCount) {
                    val child = ops.getChildAt(i) as Button
                    child.setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (i == 0) green else Color.rgb(38, 52, 72)))
                }
            }
        }
        root.addView(clear, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
        root.addView(TextView(this).apply {
            text = "সহজ ও দ্রুত হিসাব"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }, matchWrap())
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(muted)
        setPadding(0, 0, 0, dp(6))
    }

    private fun numberInput(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 18f
        setTextColor(white)
        setHintTextColor(muted)
        setSingleLine(true)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or
            android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
            android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(112, 226, 181)))
    }

    private fun calculate() {
        error.text = ""
        val aText = first.text.toString().trim()
        val bText = second.text.toString().trim()
        if (aText.isEmpty() || bText.isEmpty()) {
            answer.text = "—"
            equation.text = "দুটি সংখ্যাই লিখুন"
            return
        }
        try {
            val a = BigDecimal(aText)
            val b = BigDecimal(bText)
            if (operation == "/" && b.compareTo(BigDecimal.ZERO) == 0) {
                answer.text = "—"
                equation.text = ""
                error.text = "শূন্য দিয়ে ভাগ করা যায় না।"
                return
            }
            val result = when (operation) {
                "+" -> a.add(b)
                "-" -> a.subtract(b)
                "*" -> a.multiply(b)
                else -> a.divide(b, MathContext.DECIMAL128)
            }.stripTrailingZeros()
            val formatted = result.toPlainString()
            answer.text = formatted
            val symbol = if (operation == "*") "×" else if (operation == "/") "÷" else operation
            equation.text = "${a.stripTrailingZeros().toPlainString()} $symbol ${b.stripTrailingZeros().toPlainString()} = $formatted"
        } catch (_: NumberFormatException) {
            error.text = "সঠিক সংখ্যা লিখুন।"
        } catch (_: ArithmeticException) {
            error.text = "এই হিসাবটি করা যাচ্ছে না।"
        }
    }
}
